/****************************************************************
** Name: [agdSp].[uspAuthCallLogUpdate]
** Desc: 國際電話申請紀錄更新
**
** Return values: 0 成功
** Return Recordset: 
**	NA
**
** Called by: 
**	AGD WebApi
**
** Parameters:
**	Input
** -----------
    @CustKey         NUMERIC(38,0) - 顧客識別流水號
	@CustomerID      VARCHAR(20)  - 顧客ID
	@CustomerName    NVARCHAR(200) - 顧客姓名
	@PhoneNumber     VARCHAR(20)  - 電話號碼
	@AuthCallReason  NVARCHAR(50) - 國際電話撥號原因
	@Approver        VARCHAR(11)  - 審核人
	@ApproverName    NVARCHAR(50) - 審核人員
	@ApproveDT       DATETIME2(7) - 審核日期
	@ApproveStatus   CHAR(1)      - 審核狀態
	@CreateDT        DATETIME2(7) - 建立時間
	@CreatorName     NVARCHAR(60) - 建立人員
	@Updater 		VARCHAR(11)		- 更新者
	@UpdaterName 	NVARCHAR(60)	- 更新人員
**
**   Output
** -----------
	@ErrorMsg 		NVARCHAR(100) 	- 錯誤回傳訊息
** 
** Example:
** -----------
DECLARE @return_value INT
    ,@CustKey NUMERIC(38,0)
	,@CustomerID VARCHAR(20)
	,@CustomerName NVARCHAR(200)
	,@PhoneNumber VARCHAR(20)
	,@AuthCallReason NVARCHAR(50)
	,@Approver VARCHAR(11)
	,@ApproverName NVARCHAR(50)
	,@ApproveDT DATETIME2(7)
	,@ApproveStatus CHAR(1)
	,@CreateDT DATETIME2(7)
	,@CreatorName NVARCHAR(60)
	,@Updater VARCHAR(11)
	,@UpdaterName NVARCHAR(60)
    ,@ErrorMsg NVARCHAR(100)

    SET @CustKey = 1
	SET @CustomerID = 'abcd'
	SET @CustomerName = 'abcd'
	SET @PhoneNumber = 'abcd'
	SET @AuthCallReason = 'abcd'
	SET @Approver = 'abcd'
	SET @ApproverName = 'abcd'
	SET @ApproveDT = '2022-02-02'
	SET @ApproveStatus = 'abcd'
	SET @CreateDT = '2022-02-02'
	SET @CreatorName = 'abcd'
	SET @Updater = 'admin'
	SET @UpdaterName = 'admin'

EXEC @return_value = [agdSp].[uspAuthCallLogUpdate]
    @CustKey = @CustKey
	,@CustomerID = @CustomerID
	,@CustomerName = @CustomerName
	,@PhoneNumber = @PhoneNumber
	,@AuthCallReason = @AuthCallReason
	,@Approver = @Approver
	,@ApproverName = @ApproverName
	,@ApproveDT = @ApproveDT
	,@ApproveStatus = @ApproveStatus
	,@CreateDT = @CreateDT
	,@CreatorName = @CreatorName
	,@Updater = @Updater
	,@UpdaterName = @UpdaterName
	,@ErrorMsg = @ErrorMsg OUTPUT

SELECT @return_value AS 'Return Value'
    ,@ErrorMsg AS N'@ErrorMsg'
**
*****************************************************************
** Change History
*****************************************************************
** Date:            Author:         Description:
** ---------- ------- ------------------------------------
** 2022/06/15 10:41:42    Daniel Chou	    first release
*****************************************************************/
CREATE PROCEDURE [agdSp].[uspAuthCallLogUpdate] (
	@CustKey NUMERIC(38,0)
	,@CustomerID VARCHAR(20)
	,@CustomerName NVARCHAR(200)
	,@PhoneNumber VARCHAR(20)
	,@AuthCallReason NVARCHAR(50)
	,@Approver VARCHAR(11)
	,@ApproverName NVARCHAR(50)
	,@ApproveDT DATETIME2(7)
	,@ApproveStatus CHAR(1)
	,@CreateDT DATETIME2(7)
	,@CreatorName NVARCHAR(60)
	,@Updater VARCHAR(11)
	,@UpdaterName NVARCHAR(60)
	,@ErrorMsg NVARCHAR(100) = NULL OUTPUT
	)
AS
SET NOCOUNT ON
SET @ErrorMsg = N''

BEGIN
	BEGIN TRY
		UPDATE agd.tbAuthCallLog
		SET CustKey = @CustKey
			,CustomerID = @CustomerID
			,CustomerName = @CustomerName
			,PhoneNumber = @PhoneNumber
			,AuthCallReason = @AuthCallReason
			,Approver = @Approver
			,ApproverName = @ApproverName
			,ApproveDT = @ApproveDT
			,ApproveStatus = @ApproveStatus
			,CreateDT = @CreateDT
			,CreatorName = @CreatorName
            ,UpdateDT = DATEADD(HH, +8, GETUTCDATE())
			,Updater = @Updater
			,UpdaterName = @UpdaterName
		WHERE  = @;
	END TRY

	BEGIN CATCH
		SELECT @ErrorMsg = LEFT(ERROR_MESSAGE(), 100)
	END CATCH
END

SET NOCOUNT OFF