/****************************************************************
** Name: [agdSp].[uspTxnLogNoSaleInsert]
** Desc: 交易紀錄-不行銷註記新增
**
** Return values: 0 成功
** Return Recordset: 
**	NA
**
** Called by: 
**	AGD WebApi
**
** Parameters:
**	Input
** -----------
	@PrimaryRecordingID VARCHAR(100) - 主要錄音ID
	@CustKey         NUMERIC(38,0) - 顧客識別流水號
	@CustomerID      VARCHAR(20)  - 顧客ID
	@CustomerName    NVARCHAR(200) - 顧客姓名
	@FlagType        VARCHAR(10)  - 註記類別
	@SaleType        CHAR(1)      - 註記結果
	@IDMark          NVARCHAR(10) - ID重號註記
	@ReviewStatus    CHAR(1)      - 覆核狀態
	@ReviewMemo      NVARCHAR(50) - 覆核備註
	@CreateDT        DATETIME2(7) - 建立時間
	@CreatorName     NVARCHAR(60) - 建立人員
	@ReviewDT        DATETIME2(7) - 完成覆核時間
	@Reviewer        VARCHAR(11)  - 覆核者
	@ReviewerName    NVARCHAR(60) - 覆核人員
	@Creator		 VARCHAR(11) - 建立者
	@CreatorName	 NVARCHAR(60) - 建立人員
**
**   Output
** -----------
	@ErrorMsg NVARCHAR(100) - 錯誤回傳訊息
** 
** Example: 
** -----------
DECLARE @return_value INT
	,@PrimaryRecordingID VARCHAR(100)
	,@CustKey NUMERIC(38,0)
	,@CustomerID VARCHAR(20)
	,@CustomerName NVARCHAR(200)
	,@FlagType VARCHAR(10)
	,@SaleType CHAR(1)
	,@IDMark NVARCHAR(10)
	,@ReviewStatus CHAR(1)
	,@ReviewMemo NVARCHAR(50)
	,@CreateDT DATETIME2(7)
	,@CreatorName NVARCHAR(60)
	,@ReviewDT DATETIME2(7)
	,@Reviewer VARCHAR(11)
	,@ReviewerName NVARCHAR(60)
	,@Creator VARCHAR(11)
	,@CreatorName NVARCHAR(60)
	,@ErrorMsg NVARCHAR(100);

	SET @PrimaryRecordingID = 'abcd'
	SET @CustKey = 1
	SET @CustomerID = 'abcd'
	SET @CustomerName = 'abcd'
	SET @FlagType = 'abcd'
	SET @SaleType = 'a'
	SET @IDMark = 'abcd'
	SET @ReviewStatus = 'a'
	SET @ReviewMemo = 'abcd'
	SET @CreateDT = '2022-02-02'
	SET @CreatorName = 'abcd'
	SET @ReviewDT = '2022-02-02'
	SET @Reviewer = 'abcd'
	SET @ReviewerName = 'abcd'
	SET @Creator = 'admin'
	SET @CreatorName = 'admin'

	EXEC @return_value = [agdSp].[uspTxnLogNoSaleInsert] 
	@PrimaryRecordingID = @PrimaryRecordingID
	,@CustKey = @CustKey
	,@CustomerID = @CustomerID
	,@CustomerName = @CustomerName
	,@FlagType = @FlagType
	,@SaleType = @SaleType
	,@IDMark = @IDMark
	,@ReviewStatus = @ReviewStatus
	,@ReviewMemo = @ReviewMemo
	,@CreateDT = @CreateDT
	,@CreatorName = @CreatorName
	,@ReviewDT = @ReviewDT
	,@Reviewer = @Reviewer
	,@ReviewerName = @ReviewerName
	,@Creator = @Creator
	,@CreatorName = @CreatorName
	,@ErrorMsg = @ErrorMsg OUTPUT

SELECT @return_value AS 'Return Value'
	,@ErrorMsg AS N'@ErrorMsg'
**
*****************************************************************
** Change History
*****************************************************************
** Date:            Author:         Description:
** ---------- ------- ------------------------------------
** 2022/06/15 10:41:42    Daniel Chou	    first release
*****************************************************************/
CREATE PROCEDURE [agdSp].[uspTxnLogNoSaleInsert] (
	@PrimaryRecordingID VARCHAR(100)
	,@CustKey NUMERIC(38,0)
	,@CustomerID VARCHAR(20)
	,@CustomerName NVARCHAR(200)
	,@FlagType VARCHAR(10)
	,@SaleType CHAR(1)
	,@IDMark NVARCHAR(10)
	,@ReviewStatus CHAR(1)
	,@ReviewMemo NVARCHAR(50)
	,@CreateDT DATETIME2(7)
	,@CreatorName NVARCHAR(60)
	,@ReviewDT DATETIME2(7)
	,@Reviewer VARCHAR(11)
	,@ReviewerName NVARCHAR(60)
	,@Creator 		VARCHAR(11)
	,@CreatorName	NVARCHAR(60)
	,@ErrorMsg 		NVARCHAR(100) = NULL OUTPUT
	)
AS
SET NOCOUNT ON
SET @ErrorMsg = N''

BEGIN
	BEGIN TRY
	INSERT INTO [agd].[tbTxnLogNoSale] (
			PrimaryRecordingID
			,CustKey
			,CustomerID
			,CustomerName
			,FlagType
			,SaleType
			,IDMark
			,ReviewStatus
			,ReviewMemo
			,CreateDT
			,CreatorName
			,ReviewDT
			,Reviewer
			,ReviewerName
			,CreateDT
			,Creator
			,CreatorName
			,UpdateDT
			,Updater
			,UpdaterName
        )
		VALUES (
			@PrimaryRecordingID
			,@CustKey
			,@CustomerID
			,@CustomerName
			,@FlagType
			,@SaleType
			,@IDMark
			,@ReviewStatus
			,@ReviewMemo
			,@CreateDT
			,@CreatorName
			,@ReviewDT
			,@Reviewer
			,@ReviewerName
			,DATEADD(HH, +8, GETUTCDATE())
			,@Creator
			,@CreatorName
			,DATEADD(HH, +8, GETUTCDATE())
			,@Creator
			,@CreatorName
			);
	END TRY

	BEGIN CATCH
		SELECT @ErrorMsg = LEFT(ERROR_MESSAGE(), 100)
	END CATCH
END

SET NOCOUNT OFF