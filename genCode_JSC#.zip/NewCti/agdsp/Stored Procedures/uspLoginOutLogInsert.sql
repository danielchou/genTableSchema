/****************************************************************
** Name: [agdSp].[uspLoginOutLogInsert]
** Desc: 登出入紀錄新增
**
** Return values: 0 成功
** Return Recordset: 
**	NA
**
** Called by: 
**	AGD WebApi
**
** Parameters:
**	Input
** -----------
	@UserID          VARCHAR(11)  - 員工編號
	@UserName        NVARCHAR(60) - 員工姓名
	@LoginIP         VARCHAR(20)  - 登入IP
	@LoginSystemType VARCHAR(20)  - 登入系統類別
	@LoginDT         DATETIME2(7) - 登入時間
	@LogoutDT        DATETIME2(7) - 登出時間
	@CreateDT        DATETIME2(7) - 建立時間
	@CreatorName     NVARCHAR(60) - 建立人員
	@Creator		 VARCHAR(11) - 建立者
	@CreatorName	 NVARCHAR(60) - 建立人員
**
**   Output
** -----------
	@ErrorMsg NVARCHAR(100) - 錯誤回傳訊息
** 
** Example: 
** -----------
DECLARE @return_value INT
	,@UserID VARCHAR(11)
	,@UserName NVARCHAR(60)
	,@LoginIP VARCHAR(20)
	,@LoginSystemType VARCHAR(20)
	,@LoginDT DATETIME2(7)
	,@LogoutDT DATETIME2(7)
	,@CreateDT DATETIME2(7)
	,@CreatorName NVARCHAR(60)
	,@Creator VARCHAR(11)
	,@CreatorName NVARCHAR(60)
	,@ErrorMsg NVARCHAR(100);

	SET @UserID = 'abcd'
	SET @UserName = 'abcd'
	SET @LoginIP = 'abcd'
	SET @LoginSystemType = 'abcd'
	SET @LoginDT = '2022-02-02'
	SET @LogoutDT = '2022-02-02'
	SET @CreateDT = '2022-02-02'
	SET @CreatorName = 'abcd'
	SET @Creator = 'admin'
	SET @CreatorName = 'admin'

	EXEC @return_value = [agdSp].[uspLoginOutLogInsert] 
	@UserID = @UserID
	,@UserName = @UserName
	,@LoginIP = @LoginIP
	,@LoginSystemType = @LoginSystemType
	,@LoginDT = @LoginDT
	,@LogoutDT = @LogoutDT
	,@CreateDT = @CreateDT
	,@CreatorName = @CreatorName
	,@Creator = @Creator
	,@CreatorName = @CreatorName
	,@ErrorMsg = @ErrorMsg OUTPUT

SELECT @return_value AS 'Return Value'
	,@ErrorMsg AS N'@ErrorMsg'
**
*****************************************************************
** Change History
*****************************************************************
** Date:            Author:         Description:
** ---------- ------- ------------------------------------
** 2022/06/15 10:41:43    Daniel Chou	    first release
*****************************************************************/
CREATE PROCEDURE [agdSp].[uspLoginOutLogInsert] (
	@UserID VARCHAR(11)
	,@UserName NVARCHAR(60)
	,@LoginIP VARCHAR(20)
	,@LoginSystemType VARCHAR(20)
	,@LoginDT DATETIME2(7)
	,@LogoutDT DATETIME2(7)
	,@CreateDT DATETIME2(7)
	,@CreatorName NVARCHAR(60)
	,@Creator 		VARCHAR(11)
	,@CreatorName	NVARCHAR(60)
	,@ErrorMsg 		NVARCHAR(100) = NULL OUTPUT
	)
AS
SET NOCOUNT ON
SET @ErrorMsg = N''

BEGIN
	BEGIN TRY
	INSERT INTO [agd].[tbLoginOutLog] (
			UserID
			,UserName
			,LoginIP
			,LoginSystemType
			,LoginDT
			,LogoutDT
			,CreateDT
			,CreatorName
			,CreateDT
			,Creator
			,CreatorName
			,UpdateDT
			,Updater
			,UpdaterName
        )
		VALUES (
			@UserID
			,@UserName
			,@LoginIP
			,@LoginSystemType
			,@LoginDT
			,@LogoutDT
			,@CreateDT
			,@CreatorName
			,DATEADD(HH, +8, GETUTCDATE())
			,@Creator
			,@CreatorName
			,DATEADD(HH, +8, GETUTCDATE())
			,@Creator
			,@CreatorName
			);
	END TRY

	BEGIN CATCH
		SELECT @ErrorMsg = LEFT(ERROR_MESSAGE(), 100)
	END CATCH
END

SET NOCOUNT OFF