/****************************************************************
** Name: [agdSp].[uspAuthCallLogInsert]
** Desc: 國際電話申請紀錄新增
**
** Return values: 0 成功
** Return Recordset: 
**	NA
**
** Called by: 
**	AGD WebApi
**
** Parameters:
**	Input
** -----------
	@CustKey         NUMERIC(38,0) - 顧客識別流水號
	@CustomerID      VARCHAR(20)  - 顧客ID
	@CustomerName    NVARCHAR(200) - 顧客姓名
	@PhoneNumber     VARCHAR(20)  - 電話號碼
	@AuthCallReason  NVARCHAR(50) - 國際電話撥號原因
	@Approver        VARCHAR(11)  - 審核人
	@ApproverName    NVARCHAR(50) - 審核人員
	@ApproveDT       DATETIME2(7) - 審核日期
	@ApproveStatus   CHAR(1)      - 審核狀態
	@CreateDT        DATETIME2(7) - 建立時間
	@CreatorName     NVARCHAR(60) - 建立人員
	@Creator		 VARCHAR(11) - 建立者
	@CreatorName	 NVARCHAR(60) - 建立人員
**
**   Output
** -----------
	@ErrorMsg NVARCHAR(100) - 錯誤回傳訊息
** 
** Example: 
** -----------
DECLARE @return_value INT
	,@CustKey NUMERIC(38,0)
	,@CustomerID VARCHAR(20)
	,@CustomerName NVARCHAR(200)
	,@PhoneNumber VARCHAR(20)
	,@AuthCallReason NVARCHAR(50)
	,@Approver VARCHAR(11)
	,@ApproverName NVARCHAR(50)
	,@ApproveDT DATETIME2(7)
	,@ApproveStatus CHAR(1)
	,@CreateDT DATETIME2(7)
	,@CreatorName NVARCHAR(60)
	,@Creator VARCHAR(11)
	,@CreatorName NVARCHAR(60)
	,@ErrorMsg NVARCHAR(100);

	SET @CustKey = 1
	SET @CustomerID = 'abcd'
	SET @CustomerName = 'abcd'
	SET @PhoneNumber = 'abcd'
	SET @AuthCallReason = 'abcd'
	SET @Approver = 'abcd'
	SET @ApproverName = 'abcd'
	SET @ApproveDT = '2022-02-02'
	SET @ApproveStatus = 'abcd'
	SET @CreateDT = '2022-02-02'
	SET @CreatorName = 'abcd'
	SET @Creator = 'admin'
	SET @CreatorName = 'admin'

	EXEC @return_value = [agdSp].[uspAuthCallLogInsert] 
	@CustKey = @CustKey
	,@CustomerID = @CustomerID
	,@CustomerName = @CustomerName
	,@PhoneNumber = @PhoneNumber
	,@AuthCallReason = @AuthCallReason
	,@Approver = @Approver
	,@ApproverName = @ApproverName
	,@ApproveDT = @ApproveDT
	,@ApproveStatus = @ApproveStatus
	,@CreateDT = @CreateDT
	,@CreatorName = @CreatorName
	,@Creator = @Creator
	,@CreatorName = @CreatorName
	,@ErrorMsg = @ErrorMsg OUTPUT

SELECT @return_value AS 'Return Value'
	,@ErrorMsg AS N'@ErrorMsg'
**
*****************************************************************
** Change History
*****************************************************************
** Date:            Author:         Description:
** ---------- ------- ------------------------------------
** 2022/06/15 10:41:43    Daniel Chou	    first release
*****************************************************************/
CREATE PROCEDURE [agdSp].[uspAuthCallLogInsert] (
	@CustKey NUMERIC(38,0)
	,@CustomerID VARCHAR(20)
	,@CustomerName NVARCHAR(200)
	,@PhoneNumber VARCHAR(20)
	,@AuthCallReason NVARCHAR(50)
	,@Approver VARCHAR(11)
	,@ApproverName NVARCHAR(50)
	,@ApproveDT DATETIME2(7)
	,@ApproveStatus CHAR(1)
	,@CreateDT DATETIME2(7)
	,@CreatorName NVARCHAR(60)
	,@Creator 		VARCHAR(11)
	,@CreatorName	NVARCHAR(60)
	,@ErrorMsg 		NVARCHAR(100) = NULL OUTPUT
	)
AS
SET NOCOUNT ON
SET @ErrorMsg = N''

BEGIN
	BEGIN TRY
	INSERT INTO [agd].[tbAuthCallLog] (
			CustKey
			,CustomerID
			,CustomerName
			,PhoneNumber
			,AuthCallReason
			,Approver
			,ApproverName
			,ApproveDT
			,ApproveStatus
			,CreateDT
			,CreatorName
			,CreateDT
			,Creator
			,CreatorName
			,UpdateDT
			,Updater
			,UpdaterName
        )
		VALUES (
			@CustKey
			,@CustomerID
			,@CustomerName
			,@PhoneNumber
			,@AuthCallReason
			,@Approver
			,@ApproverName
			,@ApproveDT
			,@ApproveStatus
			,@CreateDT
			,@CreatorName
			,DATEADD(HH, +8, GETUTCDATE())
			,@Creator
			,@CreatorName
			,DATEADD(HH, +8, GETUTCDATE())
			,@Creator
			,@CreatorName
			);
	END TRY

	BEGIN CATCH
		SELECT @ErrorMsg = LEFT(ERROR_MESSAGE(), 100)
	END CATCH
END

SET NOCOUNT OFF