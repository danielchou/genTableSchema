﻿namespace ESUN.AGD.WebApi.Models
{
    public partial class TbTxnLogNoSale : CommonModel
    {
        
        /// <summary>
        /// 流水號
        /// </summary>
        public int SeqNo { get; set; } 
        /// <summary>
        /// 主要錄音ID
        /// </summary>
        public string? PrimaryRecordingID { get; set; } 
        /// <summary>
        /// 顧客識別流水號
        /// </summary>
        public int CustKey { get; set; } 
        /// <summary>
        /// 顧客ID
        /// </summary>
        public string CustomerID { get; set; }  = null!;
        /// <summary>
        /// 顧客姓名
        /// </summary>
        public string CustomerName { get; set; }  = null!;
        /// <summary>
        /// 註記類別
        /// </summary>
        public string FlagType { get; set; }  = null!;
        /// <summary>
        /// 註記結果
        /// </summary>
        public string SaleType { get; set; } 
        /// <summary>
        /// ID重號註記
        /// </summary>
        public string? IDMark { get; set; } 
        /// <summary>
        /// 覆核狀態
        /// </summary>
        public string ReviewStatus { get; set; } 
        /// <summary>
        /// 覆核備註
        /// </summary>
        public string? ReviewMemo { get; set; } 
        /// <summary>
        /// 完成覆核時間
        /// </summary>
        public DateTime? ReviewDT { get; set; } 
        /// <summary>
        /// 覆核者
        /// </summary>
        public string? Reviewer { get; set; } 
        /// <summary>
        /// 覆核人員
        /// </summary>
        public string? ReviewerName { get; set; } 
    }
}

