﻿namespace ESUN.AGD.WebApi.Models
{
    public partial class TbAuthCallLog : CommonModel
    {
        
        /// <summary>
        /// 流水號
        /// </summary>
        public int SeqNo { get; set; } 
        /// <summary>
        /// 顧客識別流水號
        /// </summary>
        public int CustKey { get; set; } 
        /// <summary>
        /// 顧客ID
        /// </summary>
        public string CustomerID { get; set; }  = null!;
        /// <summary>
        /// 顧客姓名
        /// </summary>
        public string CustomerName { get; set; }  = null!;
        /// <summary>
        /// 電話號碼
        /// </summary>
        public string PhoneNumber { get; set; }  = null!;
        /// <summary>
        /// 國際電話撥號原因
        /// </summary>
        public string AuthCallReason { get; set; }  = null!;
        /// <summary>
        /// 審核人
        /// </summary>
        public string? Approver { get; set; } 
        /// <summary>
        /// 審核人員
        /// </summary>
        public string? ApproverName { get; set; } 
        /// <summary>
        /// 審核日期
        /// </summary>
        public DateTime? ApproveDT { get; set; } 
        /// <summary>
        /// 審核狀態
        /// </summary>
        public string ApproveStatus { get; set; } 
    }
}

