﻿namespace ESUN.AGD.WebApi.Models
{
    public partial class TbLoginOutLog : CommonModel
    {
        
        /// <summary>
        /// 流水號
        /// </summary>
        public int SeqNo { get; set; } 
        /// <summary>
        /// 員工編號
        /// </summary>
        public string UserID { get; set; }  = null!;
        /// <summary>
        /// 員工姓名
        /// </summary>
        public string UserName { get; set; }  = null!;
        /// <summary>
        /// 登入IP
        /// </summary>
        public string LoginIP { get; set; }  = null!;
        /// <summary>
        /// 登入系統類別
        /// </summary>
        public string LoginSystemType { get; set; }  = null!;
        /// <summary>
        /// 登入時間
        /// </summary>
        public DateTime LoginDT { get; set; } 
        /// <summary>
        /// 登出時間
        /// </summary>
        public DateTime? LogoutDT { get; set; } 
    }
}

