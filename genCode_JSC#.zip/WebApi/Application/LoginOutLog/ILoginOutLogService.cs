﻿using ESUN.AGD.WebApi.Application.LoginOutLog.Contract;

namespace ESUN.AGD.WebApi.Application.LoginOutLog
{
    public interface ILoginOutLogService
    {
        /// <summary>
        /// 依序號取得登出入紀錄設定
        /// </summary>
        /// <param>
		/// userID           - string     - 員工編號
		/// createDT         - DateTime   - 建立時間
        /// </param>
        /// <returns>
		/// seqNo            - int        - 流水號
		/// userID           - string     - 員工編號
		/// userName         - string     - 員工姓名
		/// loginIP          - string     - 登入IP
		/// loginSystemType  - string     - 登入系統類別
		/// loginDT          - DateTime   - 登入時間
		/// logoutDT         - DateTime   - 登出時間
		/// createDT         - DateTime   - 建立時間
		/// creator          - string     - 建立者
		/// creatorName      - string     - 建立人員
        /// </returns>
        ValueTask<BasicResponse<LoginOutLogResponse>> GetLoginOutLog(string userID,DateTime createDT);

        /// <summary>
        /// 搜尋登出入紀錄設定 
        /// </summary>
        /// <param name="request">
		/// seqNo            - int        - 流水號
		/// userID           - string     - 員工編號
		/// userName         - string     - 員工姓名
		/// loginIP          - string     - 登入IP
		/// loginSystemType  - string     - 登入系統類別
		/// loginDT          - DateTime   - 登入時間
		/// logoutDT         - DateTime   - 登出時間
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
        /// page             - int        - 分頁
        /// rowsPerPage      - int        - 每頁筆數
        /// sortColumn       - string     - 排序欄位
        /// sortOrder        - string     - 排序順序
        /// </param>
        /// <returns>
		/// seqNo            - int        - 流水號
		/// userID           - string     - 員工編號
		/// userName         - string     - 員工姓名
		/// loginIP          - string     - 登入IP
		/// loginSystemType  - string     - 登入系統類別
		/// loginDT          - DateTime   - 登入時間
		/// logoutDT         - DateTime   - 登出時間
		/// createDT         - DateTime   - 建立時間
		/// creator          - string     - 建立者
		/// creatorName      - string     - 建立人員
        /// </returns> 
        ValueTask<BasicResponse<List<LoginOutLogResponse>>> QueryLoginOutLog(LoginOutLogQueryRequest request);

        /// <summary>
        /// 新增登出入紀錄設定 
        /// </summary>
        /// <param name="request">
		/// userID           - string     - 員工編號
		/// userName         - string     - 員工姓名
		/// loginIP          - string     - 登入IP
		/// loginSystemType  - string     - 登入系統類別
		/// loginDT          - DateTime   - 登入時間
		/// logoutDT         - DateTime   - 登出時間
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
        /// </param>
        /// <returns>
        /// </returns>
        ValueTask<BasicResponse<bool>> InsertLoginOutLog(LoginOutLogInsertRequest request);

        /// <summary>
        /// 更新登出入紀錄設定
        /// </summary>
        /// <param name="request">
		/// userID           - string     - 員工編號
		/// userName         - string     - 員工姓名
		/// loginIP          - string     - 登入IP
		/// loginSystemType  - string     - 登入系統類別
		/// loginDT          - DateTime   - 登入時間
		/// logoutDT         - DateTime   - 登出時間
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
        /// </param>
        /// <returns>
        /// </returns>
        ValueTask<BasicResponse<bool>> UpdateLoginOutLog(LoginOutLogUpdateRequest request);

        /// <summary>
        /// 刪除登出入紀錄設定
        /// </summary>
        /// <param>
		/// userID           - string     - 員工編號
		/// createDT         - DateTime   - 建立時間
        /// </param>
        /// <returns>
        /// </returns>
        ValueTask<BasicResponse<bool>> DeleteLoginOutLog(string userID,DateTime createDT);

        /// <summary>
        /// 檢查登出入紀錄是否存在
        /// </summary>
        /// <param>
		/// userID           - string     - 員工編號
		/// userName         - string     - 員工姓名
		/// loginIP          - string     - 登入IP
		/// loginSystemType  - string     - 登入系統類別
		/// loginDT          - DateTime   - 登入時間
		/// logoutDT         - DateTime   - 登出時間
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
        /// </param>
        /// <returns>
        /// </returns>
        ValueTask<BasicResponse<bool>> Exists(string userID, string userName, string loginIP, string loginSystemType, DateTime loginDT, DateTime? logoutDT, DateTime createDT, string creatorName);

    }
}
