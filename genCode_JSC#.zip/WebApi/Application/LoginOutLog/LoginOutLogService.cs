using ESUN.AGD.WebApi.Application.Auth;
using ESUN.AGD.WebApi.Application.LoginOutLog.Contract;
using ESUN.AGD.DataAccess.DataService.DataAccess;

namespace ESUN.AGD.WebApi.Application.LoginOutLog
{
    public class LoginOutLogService : ILoginOutLogService
    {

        private readonly IDataAccessService _dataAccessService;
        private readonly IGetTokenService _getTokenService;
        private IHttpContextAccessor _context;
        private string serviceName = string.Empty;
        private IMapper _mapper;
       
        public LoginOutLogService(IDataAccessService dataAccessService
                              , IGetTokenService getTokenService
                              , IHttpContextAccessor context
                              , IMapper mapper)
        {
            _dataAccessService = dataAccessService;
            _getTokenService = getTokenService;
            _context = context;
            serviceName = this.GetType().Name;
            _mapper = mapper;
        }

        public async ValueTask<BasicResponse<LoginOutLogResponse>> GetLoginOutLog(string userID,DateTime createDT)
        {
            var method = _context?.HttpContext?.Request?.Method;
            var data = await _dataAccessService
                .LoadSingleData<TbLoginOutLog, object>(storeProcedure: "agdSp.uspLoginOutLogGet", new { userID,createDT = userID,createDT, });
            
      		return ResponseHandler.ForData<LoginOutLogResponse>(data, _mapper, serviceName, method, 0);
        }

        public async ValueTask<BasicResponse<List<LoginOutLogResponse>>> QueryLoginOutLog(LoginOutLogQueryRequest request)
        {
			var method = _context?.HttpContext?.Request.Path.ToString().Split("/")[3];

			if (string.IsNullOrEmpty(request.userID)) { request.userID = string.Empty; }
			if (string.IsNullOrEmpty(request.userName)) { request.userName = string.Empty; }
			if (string.IsNullOrEmpty(request.loginIP)) { request.loginIP = string.Empty; }
			if (string.IsNullOrEmpty(request.loginSystemType)) { request.loginSystemType = string.Empty; }
			if (string.IsNullOrEmpty(request.creatorName)) { request.creatorName = string.Empty; }

            var data = await _dataAccessService
                .LoadData<TbLoginOutLog, object>(storeProcedure: "agdSp.uspLoginOutLogQuery", request);
                
            int totalCount = data == null ? 0 : data.FirstOrDefault().Total;
			
			return ResponseHandler.ForData<List<LoginOutLogResponse>>(data, _mapper, serviceName, method, totalCount);
        }

        public async ValueTask<BasicResponse<bool>> InsertLoginOutLog(LoginOutLogInsertRequest request)
        {
			var method = _context?.HttpContext?.Request?.Method;            
			
			var exists = await Exists(0, request.userName, request.loginIP, request.loginSystemType, request.loginDT, request.logoutDT, request.creatorName);
            
            if (exists.data == true)
                return ResponseHandler.ForCustomBool(serviceName, false, "資料重複，員工姓名+登入IP+登入系統類別+登入時間+登出時間+建立人員重複，請重新設定");

            var creator = _getTokenService.userID ?? "";
            var creatorName = _getTokenService.userName ?? "";
                          
            request.creator = creator;
            request.creatorName = creatorName;

            var data = await _dataAccessService
                .OperateData(storeProcedure: "agdSp.uspLoginOutLogInsert", request);

			return ResponseHandler.ForBool(data, serviceName, method);
        }

        public async ValueTask<BasicResponse<bool>> UpdateLoginOutLog(LoginOutLogUpdateRequest request)
        {
            var method = _context?.HttpContext?.Request?.Method;

			var exists = await Exists(request.userID, request.userName, request.loginIP, request.loginSystemType, request.loginDT, request.logoutDT, request.createDT, request.creatorName);
            
            if (exists.data == true)
                return ResponseHandler.ForCustomBool(serviceName, false, "資料重複，員工姓名+登入IP+登入系統類別+登入時間+登出時間+建立人員重複，請重新設定");

            var updater = _getTokenService.userID ?? "";
            var updaterName = _getTokenService.userName ?? "";

            request.updater = updater;
            request.updaterName = updaterName;

            var data = await _dataAccessService
                .OperateData(storeProcedure: "agdSp.uspLoginOutLogUpdate", request);

			return ResponseHandler.ForBool(data, serviceName, method);
        }

        public async ValueTask<BasicResponse<bool>> DeleteLoginOutLog(string userID,DateTime createDT)
        {
			var method = _context?.HttpContext?.Request?.Method;
            
			var data = await _dataAccessService
                .OperateData(storeProcedure: "agdSp.uspLoginOutLogDelete", new { userID,createDT = userID,createDT });

			return ResponseHandler.ForBool(data, serviceName, method);
        }

        public async ValueTask<BasicResponse<bool>> Exists(string userID, string userName, string loginIP, string loginSystemType, DateTime loginDT, DateTime? logoutDT, DateTime createDT, string creatorName)
        {
            var data = await _dataAccessService
                .LoadSingleData<int, object>(storeProcedure: "agdSp.uspLoginOutLogExists", new
                {
					UserID = userID,
					UserName = userName,
					LoginIP = loginIP,
					LoginSystemType = loginSystemType,
					LoginDT = loginDT,
					LogoutDT = logoutDT,
					CreateDT = createDT,
					CreatorName = creatorName,               
                });

            if (data == 0)
            {
                return ResponseHandler.ForCustomBool(serviceName, false, "資料不存在");
            }
            else
            {
                return ResponseHandler.ForCustomBool(serviceName, true, "資料存在");
            }
        }
    }
}