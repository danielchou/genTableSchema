﻿

namespace ESUN.AGD.WebApi.Application.LoginOutLog.Contract
{
    /// <summary>
    /// 進階查詢查詢請求
    /// </summary>
    public class LoginOutLogQueryRequest : CommonQuery
    {
		/// <summary>
        /// 流水號
        /// </summary>
        public int seqNo { get; set; }
		/// <summary>
        /// 員工編號
        /// </summary>
        public string? userID { get; set; }
		/// <summary>
        /// 員工姓名
        /// </summary>
        public string? userName { get; set; }
		/// <summary>
        /// 登入IP
        /// </summary>
        public string? loginIP { get; set; }
		/// <summary>
        /// 登入系統類別
        /// </summary>
        public string? loginSystemType { get; set; }
		/// <summary>
        /// 登入時間
        /// </summary>
        public DateTime? loginDT { get; set; }
		/// <summary>
        /// 登出時間
        /// </summary>
        public DateTime? logoutDT { get; set; }
		/// <summary>
        /// 建立時間
        /// </summary>
        public DateTime? createDT { get; set; }
		/// <summary>
        /// 建立人員
        /// </summary>
        public string? creatorName { get; set; }

    }
}
