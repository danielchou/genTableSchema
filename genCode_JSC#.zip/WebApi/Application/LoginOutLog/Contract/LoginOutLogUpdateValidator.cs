﻿using FluentValidation;
namespace ESUN.AGD.WebApi.Application.LoginOutLog.Contract
{
    public class LoginOutLogUpdateValidator:AbstractValidator<LoginOutLogUpdateRequest>
    {
        public LoginOutLogUpdateValidator()
        {
			RuleFor(x => x.userID).NotEmpty().WithMessage("員工編號為必填");
			RuleFor(x => x.userID).MaximumLength(11).WithMessage("員工編號長度超過系統限制");
			RuleFor(x => x.userName).NotEmpty().WithMessage("員工姓名為必填");
			RuleFor(x => x.userName).MaximumLength(60).WithMessage("員工姓名長度超過系統限制");
			RuleFor(x => x.loginIP).NotEmpty().WithMessage("登入IP為必填");
			RuleFor(x => x.loginIP).MaximumLength(20).WithMessage("登入IP長度超過系統限制");
			RuleFor(x => x.loginSystemType).NotEmpty().WithMessage("登入系統類別為必填");
			RuleFor(x => x.loginSystemType).MaximumLength(20).WithMessage("登入系統類別長度超過系統限制");
        }
    }
}
