﻿using ESUN.AGD.WebApi.Application.AuthCallLog.Contract;

namespace ESUN.AGD.WebApi.Application.AuthCallLog
{
    public interface IAuthCallLogService
    {
        /// <summary>
        /// 依序號取得國際電話申請紀錄設定
        /// </summary>
        /// <param>
		/// seqNo            - int        - 流水號
        /// </param>
        /// <returns>
		/// seqNo            - int        - 流水號
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// phoneNumber      - string     - 電話號碼
		/// authCallReason   - string     - 國際電話撥號原因
		/// approver         - string     - 審核人
		/// approverName     - string     - 審核人員
		/// approveDT        - DateTime   - 審核日期
		/// approveStatus    - string     - 審核狀態
		/// createDT         - DateTime   - 建立時間
		/// creator          - string     - 建立者
		/// creatorName      - string     - 建立人員
        /// </returns>
        ValueTask<BasicResponse<AuthCallLogResponse>> GetAuthCallLog(int seqNo);

        /// <summary>
        /// 搜尋國際電話申請紀錄設定 
        /// </summary>
        /// <param name="request">
		/// seqNo            - int        - 流水號
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// phoneNumber      - string     - 電話號碼
		/// authCallReason   - string     - 國際電話撥號原因
		/// approver         - string     - 審核人
		/// approverName     - string     - 審核人員
		/// approveDT        - DateTime   - 審核日期
		/// approveStatus    - string     - 審核狀態
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
        /// page             - int        - 分頁
        /// rowsPerPage      - int        - 每頁筆數
        /// sortColumn       - string     - 排序欄位
        /// sortOrder        - string     - 排序順序
        /// </param>
        /// <returns>
		/// seqNo            - int        - 流水號
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// phoneNumber      - string     - 電話號碼
		/// authCallReason   - string     - 國際電話撥號原因
		/// approver         - string     - 審核人
		/// approverName     - string     - 審核人員
		/// approveDT        - DateTime   - 審核日期
		/// approveStatus    - string     - 審核狀態
		/// createDT         - DateTime   - 建立時間
		/// creator          - string     - 建立者
		/// creatorName      - string     - 建立人員
        /// </returns> 
        ValueTask<BasicResponse<List<AuthCallLogResponse>>> QueryAuthCallLog(AuthCallLogQueryRequest request);

        /// <summary>
        /// 新增國際電話申請紀錄設定 
        /// </summary>
        /// <param name="request">
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// phoneNumber      - string     - 電話號碼
		/// authCallReason   - string     - 國際電話撥號原因
		/// approver         - string     - 審核人
		/// approverName     - string     - 審核人員
		/// approveDT        - DateTime   - 審核日期
		/// approveStatus    - string     - 審核狀態
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
        /// </param>
        /// <returns>
        /// </returns>
        ValueTask<BasicResponse<bool>> InsertAuthCallLog(AuthCallLogInsertRequest request);

        /// <summary>
        /// 更新國際電話申請紀錄設定
        /// </summary>
        /// <param name="request">
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// phoneNumber      - string     - 電話號碼
		/// authCallReason   - string     - 國際電話撥號原因
		/// approver         - string     - 審核人
		/// approverName     - string     - 審核人員
		/// approveDT        - DateTime   - 審核日期
		/// approveStatus    - string     - 審核狀態
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
        /// </param>
        /// <returns>
        /// </returns>
        ValueTask<BasicResponse<bool>> UpdateAuthCallLog(AuthCallLogUpdateRequest request);

        /// <summary>
        /// 刪除國際電話申請紀錄設定
        /// </summary>
        /// <param>
		/// seqNo            - int        - 流水號
        /// </param>
        /// <returns>
        /// </returns>
        ValueTask<BasicResponse<bool>> DeleteAuthCallLog(int seqNo);

        /// <summary>
        /// 檢查國際電話申請紀錄是否存在
        /// </summary>
        /// <param>
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// phoneNumber      - string     - 電話號碼
		/// authCallReason   - string     - 國際電話撥號原因
		/// approver         - string     - 審核人
		/// approverName     - string     - 審核人員
		/// approveDT        - DateTime   - 審核日期
		/// approveStatus    - string     - 審核狀態
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
        /// </param>
        /// <returns>
        /// </returns>
        ValueTask<BasicResponse<bool>> Exists(int custKey, string customerID, string customerName, string phoneNumber, string authCallReason, string? approver, string? approverName, DateTime? approveDT, string approveStatus, DateTime createDT, string creatorName);

    }
}
