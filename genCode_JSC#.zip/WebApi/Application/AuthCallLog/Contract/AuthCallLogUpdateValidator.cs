﻿using FluentValidation;
namespace ESUN.AGD.WebApi.Application.AuthCallLog.Contract
{
    public class AuthCallLogUpdateValidator:AbstractValidator<AuthCallLogUpdateRequest>
    {
        public AuthCallLogUpdateValidator()
        {
			RuleFor(x => x.customerID).NotEmpty().WithMessage("顧客ID為必填");
			RuleFor(x => x.customerID).MaximumLength(20).WithMessage("顧客ID長度超過系統限制");
			RuleFor(x => x.customerName).NotEmpty().WithMessage("顧客姓名為必填");
			RuleFor(x => x.customerName).MaximumLength(200).WithMessage("顧客姓名長度超過系統限制");
			RuleFor(x => x.phoneNumber).NotEmpty().WithMessage("電話號碼為必填");
			RuleFor(x => x.phoneNumber).MaximumLength(20).WithMessage("電話號碼長度超過系統限制");
			RuleFor(x => x.authCallReason).NotEmpty().WithMessage("國際電話撥號原因為必填");
			RuleFor(x => x.authCallReason).MaximumLength(50).WithMessage("國際電話撥號原因長度超過系統限制");
			RuleFor(x => x.approver).MaximumLength(11).WithMessage("審核人長度超過系統限制");
			RuleFor(x => x.approverName).MaximumLength(50).WithMessage("審核人員長度超過系統限制");
        }
    }
}
