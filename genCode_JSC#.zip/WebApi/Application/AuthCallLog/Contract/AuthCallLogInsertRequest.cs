﻿namespace ESUN.AGD.WebApi.Application.AuthCallLog.Contract
{
    /// <summary>
    /// 國際電話申請紀錄新增請求
    /// </summary>
    public class AuthCallLogInsertRequest : CommonInsertRequest
    {
        /// <summary>
        /// 顧客識別流水號
        /// </summary>
        public int custKey { get; set; }
        /// <summary>
        /// 顧客ID
        /// </summary>
        public string customerID { get; set; }
        /// <summary>
        /// 顧客姓名
        /// </summary>
        public string customerName { get; set; }
        /// <summary>
        /// 電話號碼
        /// </summary>
        public string phoneNumber { get; set; }
        /// <summary>
        /// 國際電話撥號原因
        /// </summary>
        public string authCallReason { get; set; }
        /// <summary>
        /// 審核人
        /// </summary>
        public string? approver { get; set; }
        /// <summary>
        /// 審核人員
        /// </summary>
        public string? approverName { get; set; }
        /// <summary>
        /// 審核日期
        /// </summary>
        public DateTime? approveDT { get; set; }
        /// <summary>
        /// 審核狀態
        /// </summary>
        public string approveStatus { get; set; }
        /// <summary>
        /// 建立時間
        /// </summary>
        public DateTime createDT { get; set; }
        /// <summary>
        /// 建立人員
        /// </summary>
        public string creatorName { get; set; }
    }
}