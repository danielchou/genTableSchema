using ESUN.AGD.WebApi.Application.Auth;
using ESUN.AGD.WebApi.Application.AuthCallLog.Contract;
using ESUN.AGD.DataAccess.DataService.DataAccess;

namespace ESUN.AGD.WebApi.Application.AuthCallLog
{
    public class AuthCallLogService : IAuthCallLogService
    {

        private readonly IDataAccessService _dataAccessService;
        private readonly IGetTokenService _getTokenService;
        private IHttpContextAccessor _context;
        private string serviceName = string.Empty;
        private IMapper _mapper;
       
        public AuthCallLogService(IDataAccessService dataAccessService
                              , IGetTokenService getTokenService
                              , IHttpContextAccessor context
                              , IMapper mapper)
        {
            _dataAccessService = dataAccessService;
            _getTokenService = getTokenService;
            _context = context;
            serviceName = this.GetType().Name;
            _mapper = mapper;
        }

        public async ValueTask<BasicResponse<AuthCallLogResponse>> GetAuthCallLog(int seqNo)
        {
            var method = _context?.HttpContext?.Request?.Method;
            var data = await _dataAccessService
                .LoadSingleData<TbAuthCallLog, object>(storeProcedure: "agdSp.uspAuthCallLogGet", new { seqNo = seqNo, });
            
      		return ResponseHandler.ForData<AuthCallLogResponse>(data, _mapper, serviceName, method, 0);
        }

        public async ValueTask<BasicResponse<List<AuthCallLogResponse>>> QueryAuthCallLog(AuthCallLogQueryRequest request)
        {
			var method = _context?.HttpContext?.Request.Path.ToString().Split("/")[3];

			if (string.IsNullOrEmpty(request.customerID)) { request.customerID = string.Empty; }
			if (string.IsNullOrEmpty(request.customerName)) { request.customerName = string.Empty; }
			if (string.IsNullOrEmpty(request.phoneNumber)) { request.phoneNumber = string.Empty; }
			if (string.IsNullOrEmpty(request.authCallReason)) { request.authCallReason = string.Empty; }
			if (string.IsNullOrEmpty(request.approver)) { request.approver = string.Empty; }
			if (string.IsNullOrEmpty(request.approverName)) { request.approverName = string.Empty; }
			if (string.IsNullOrEmpty(request.approveStatus)) { request.approveStatus = string.Empty; }
			if (string.IsNullOrEmpty(request.creatorName)) { request.creatorName = string.Empty; }

            var data = await _dataAccessService
                .LoadData<TbAuthCallLog, object>(storeProcedure: "agdSp.uspAuthCallLogQuery", request);
                
            int totalCount = data == null ? 0 : data.FirstOrDefault().Total;
			
			return ResponseHandler.ForData<List<AuthCallLogResponse>>(data, _mapper, serviceName, method, totalCount);
        }

        public async ValueTask<BasicResponse<bool>> InsertAuthCallLog(AuthCallLogInsertRequest request)
        {
			var method = _context?.HttpContext?.Request?.Method;            
			
			var exists = await Exists(0, request.custKey, request.customerID, request.customerName, request.phoneNumber, request.authCallReason, request.approver, request.approverName, request.approveDT, request.approveStatus, request.createDT, request.creatorName);
            
            if (exists.data == true)
                return ResponseHandler.ForCustomBool(serviceName, false, "資料重複，顧客識別流水號+顧客ID+顧客姓名+電話號碼+國際電話撥號原因+審核人+審核人員+審核日期+審核狀態+建立時間+建立人員重複，請重新設定");

            var creator = _getTokenService.userID ?? "";
            var creatorName = _getTokenService.userName ?? "";
                          
            request.creator = creator;
            request.creatorName = creatorName;

            var data = await _dataAccessService
                .OperateData(storeProcedure: "agdSp.uspAuthCallLogInsert", request);

			return ResponseHandler.ForBool(data, serviceName, method);
        }

        public async ValueTask<BasicResponse<bool>> UpdateAuthCallLog(AuthCallLogUpdateRequest request)
        {
            var method = _context?.HttpContext?.Request?.Method;

			var exists = await Exists(request.custKey, request.customerID, request.customerName, request.phoneNumber, request.authCallReason, request.approver, request.approverName, request.approveDT, request.approveStatus, request.createDT, request.creatorName);
            
            if (exists.data == true)
                return ResponseHandler.ForCustomBool(serviceName, false, "資料重複，顧客識別流水號+顧客ID+顧客姓名+電話號碼+國際電話撥號原因+審核人+審核人員+審核日期+審核狀態+建立時間+建立人員重複，請重新設定");

            var updater = _getTokenService.userID ?? "";
            var updaterName = _getTokenService.userName ?? "";

            request.updater = updater;
            request.updaterName = updaterName;

            var data = await _dataAccessService
                .OperateData(storeProcedure: "agdSp.uspAuthCallLogUpdate", request);

			return ResponseHandler.ForBool(data, serviceName, method);
        }

        public async ValueTask<BasicResponse<bool>> DeleteAuthCallLog(int seqNo)
        {
			var method = _context?.HttpContext?.Request?.Method;
            
			var data = await _dataAccessService
                .OperateData(storeProcedure: "agdSp.uspAuthCallLogDelete", new { seqNo = seqNo });

			return ResponseHandler.ForBool(data, serviceName, method);
        }

        public async ValueTask<BasicResponse<bool>> Exists(int custKey, string customerID, string customerName, string phoneNumber, string authCallReason, string? approver, string? approverName, DateTime? approveDT, string approveStatus, DateTime createDT, string creatorName)
        {
            var data = await _dataAccessService
                .LoadSingleData<int, object>(storeProcedure: "agdSp.uspAuthCallLogExists", new
                {
					CustKey = custKey,
					CustomerID = customerID,
					CustomerName = customerName,
					PhoneNumber = phoneNumber,
					AuthCallReason = authCallReason,
					Approver = approver,
					ApproverName = approverName,
					ApproveDT = approveDT,
					ApproveStatus = approveStatus,
					CreateDT = createDT,
					CreatorName = creatorName,               
                });

            if (data == 0)
            {
                return ResponseHandler.ForCustomBool(serviceName, false, "資料不存在");
            }
            else
            {
                return ResponseHandler.ForCustomBool(serviceName, true, "資料存在");
            }
        }
    }
}