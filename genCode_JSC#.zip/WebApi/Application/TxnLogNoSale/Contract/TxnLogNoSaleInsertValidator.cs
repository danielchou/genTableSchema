﻿using FluentValidation;
using FluentValidation.Results;

namespace ESUN.AGD.WebApi.Application.TxnLogNoSale.Contract
{
    public class  TxnLogNoSaleInsertValidator : AbstractValidator<TxnLogNoSaleInsertRequest>
    {
        public  TxnLogNoSaleInsertValidator()
        {
			RuleFor(x => x.primaryRecordingID).MaximumLength(100).WithMessage("主要錄音ID長度超過系統限制");
			RuleFor(x => x.customerID).NotEmpty().WithMessage("顧客ID為必填");
			RuleFor(x => x.customerID).MaximumLength(20).WithMessage("顧客ID長度超過系統限制");
			RuleFor(x => x.customerName).NotEmpty().WithMessage("顧客姓名為必填");
			RuleFor(x => x.customerName).MaximumLength(200).WithMessage("顧客姓名長度超過系統限制");
			RuleFor(x => x.flagType).NotEmpty().WithMessage("註記類別為必填");
			RuleFor(x => x.flagType).MaximumLength(10).WithMessage("註記類別長度超過系統限制");
			RuleFor(x => x.iDMark).MaximumLength(10).WithMessage("ID重號註記長度超過系統限制");
			RuleFor(x => x.reviewMemo).MaximumLength(50).WithMessage("覆核備註長度超過系統限制");
			RuleFor(x => x.reviewer).MaximumLength(11).WithMessage("覆核者長度超過系統限制");
			RuleFor(x => x.reviewerName).MaximumLength(60).WithMessage("覆核人員長度超過系統限制");
        }
    }
}
