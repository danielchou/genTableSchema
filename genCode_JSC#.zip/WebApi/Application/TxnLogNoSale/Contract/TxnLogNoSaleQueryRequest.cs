﻿

namespace ESUN.AGD.WebApi.Application.TxnLogNoSale.Contract
{
    /// <summary>
    /// 進階查詢查詢請求
    /// </summary>
    public class TxnLogNoSaleQueryRequest : CommonQuery
    {
		/// <summary>
        /// 流水號
        /// </summary>
        public int seqNo { get; set; }
		/// <summary>
        /// 主要錄音ID
        /// </summary>
        public string? primaryRecordingID { get; set; }
		/// <summary>
        /// 顧客識別流水號
        /// </summary>
        public int custKey { get; set; }
		/// <summary>
        /// 顧客ID
        /// </summary>
        public string? customerID { get; set; }
		/// <summary>
        /// 顧客姓名
        /// </summary>
        public string? customerName { get; set; }
		/// <summary>
        /// 註記類別
        /// </summary>
        public string? flagType { get; set; }
		/// <summary>
        /// 註記結果
        /// </summary>
        public string? saleType { get; set; }
		/// <summary>
        /// ID重號註記
        /// </summary>
        public string? iDMark { get; set; }
		/// <summary>
        /// 覆核狀態
        /// </summary>
        public string? reviewStatus { get; set; }
		/// <summary>
        /// 覆核備註
        /// </summary>
        public string? reviewMemo { get; set; }
		/// <summary>
        /// 建立時間
        /// </summary>
        public DateTime? createDT { get; set; }
		/// <summary>
        /// 建立人員
        /// </summary>
        public string? creatorName { get; set; }
		/// <summary>
        /// 完成覆核時間
        /// </summary>
        public DateTime? reviewDT { get; set; }
		/// <summary>
        /// 覆核者
        /// </summary>
        public string? reviewer { get; set; }
		/// <summary>
        /// 覆核人員
        /// </summary>
        public string? reviewerName { get; set; }

    }
}
