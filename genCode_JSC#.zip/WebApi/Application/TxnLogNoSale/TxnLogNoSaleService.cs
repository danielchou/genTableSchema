using ESUN.AGD.WebApi.Application.Auth;
using ESUN.AGD.WebApi.Application.TxnLogNoSale.Contract;
using ESUN.AGD.DataAccess.DataService.DataAccess;

namespace ESUN.AGD.WebApi.Application.TxnLogNoSale
{
    public class TxnLogNoSaleService : ITxnLogNoSaleService
    {

        private readonly IDataAccessService _dataAccessService;
        private readonly IGetTokenService _getTokenService;
        private IHttpContextAccessor _context;
        private string serviceName = string.Empty;
        private IMapper _mapper;
       
        public TxnLogNoSaleService(IDataAccessService dataAccessService
                              , IGetTokenService getTokenService
                              , IHttpContextAccessor context
                              , IMapper mapper)
        {
            _dataAccessService = dataAccessService;
            _getTokenService = getTokenService;
            _context = context;
            serviceName = this.GetType().Name;
            _mapper = mapper;
        }

        public async ValueTask<BasicResponse<TxnLogNoSaleResponse>> GetTxnLogNoSale(int seqNo)
        {
            var method = _context?.HttpContext?.Request?.Method;
            var data = await _dataAccessService
                .LoadSingleData<TbTxnLogNoSale, object>(storeProcedure: "agdSp.uspTxnLogNoSaleGet", new { seqNo = seqNo, });
            
      		return ResponseHandler.ForData<TxnLogNoSaleResponse>(data, _mapper, serviceName, method, 0);
        }

        public async ValueTask<BasicResponse<List<TxnLogNoSaleResponse>>> QueryTxnLogNoSale(TxnLogNoSaleQueryRequest request)
        {
			var method = _context?.HttpContext?.Request.Path.ToString().Split("/")[3];

			if (string.IsNullOrEmpty(request.primaryRecordingID)) { request.primaryRecordingID = string.Empty; }
			if (string.IsNullOrEmpty(request.customerID)) { request.customerID = string.Empty; }
			if (string.IsNullOrEmpty(request.customerName)) { request.customerName = string.Empty; }
			if (string.IsNullOrEmpty(request.flagType)) { request.flagType = string.Empty; }
			if (string.IsNullOrEmpty(request.saleType)) { request.saleType = string.Empty; }
			if (string.IsNullOrEmpty(request.iDMark)) { request.iDMark = string.Empty; }
			if (string.IsNullOrEmpty(request.reviewStatus)) { request.reviewStatus = string.Empty; }
			if (string.IsNullOrEmpty(request.reviewMemo)) { request.reviewMemo = string.Empty; }
			if (string.IsNullOrEmpty(request.creatorName)) { request.creatorName = string.Empty; }
			if (string.IsNullOrEmpty(request.reviewer)) { request.reviewer = string.Empty; }
			if (string.IsNullOrEmpty(request.reviewerName)) { request.reviewerName = string.Empty; }

            var data = await _dataAccessService
                .LoadData<TbTxnLogNoSale, object>(storeProcedure: "agdSp.uspTxnLogNoSaleQuery", request);
                
            int totalCount = data == null ? 0 : data.FirstOrDefault().Total;
			
			return ResponseHandler.ForData<List<TxnLogNoSaleResponse>>(data, _mapper, serviceName, method, totalCount);
        }

        public async ValueTask<BasicResponse<bool>> InsertTxnLogNoSale(TxnLogNoSaleInsertRequest request)
        {
			var method = _context?.HttpContext?.Request?.Method;            
			
			var exists = await Exists(0, request.primaryRecordingID, request.custKey, request.customerID, request.customerName, request.flagType, request.saleType, request.iDMark, request.reviewStatus, request.reviewMemo, request.createDT, request.creatorName, request.reviewDT, request.reviewer, request.reviewerName);
            
            if (exists.data == true)
                return ResponseHandler.ForCustomBool(serviceName, false, "資料重複，主要錄音ID+顧客識別流水號+顧客ID+顧客姓名+註記類別+註記結果+ID重號註記+覆核狀態+覆核備註+建立時間+建立人員+完成覆核時間+覆核者+覆核人員重複，請重新設定");

            var creator = _getTokenService.userID ?? "";
            var creatorName = _getTokenService.userName ?? "";
                          
            request.creator = creator;
            request.creatorName = creatorName;

            var data = await _dataAccessService
                .OperateData(storeProcedure: "agdSp.uspTxnLogNoSaleInsert", request);

			return ResponseHandler.ForBool(data, serviceName, method);
        }

        public async ValueTask<BasicResponse<bool>> UpdateTxnLogNoSale(TxnLogNoSaleUpdateRequest request)
        {
            var method = _context?.HttpContext?.Request?.Method;

			var exists = await Exists(request.primaryRecordingID, request.custKey, request.customerID, request.customerName, request.flagType, request.saleType, request.iDMark, request.reviewStatus, request.reviewMemo, request.createDT, request.creatorName, request.reviewDT, request.reviewer, request.reviewerName);
            
            if (exists.data == true)
                return ResponseHandler.ForCustomBool(serviceName, false, "資料重複，主要錄音ID+顧客識別流水號+顧客ID+顧客姓名+註記類別+註記結果+ID重號註記+覆核狀態+覆核備註+建立時間+建立人員+完成覆核時間+覆核者+覆核人員重複，請重新設定");

            var updater = _getTokenService.userID ?? "";
            var updaterName = _getTokenService.userName ?? "";

            request.updater = updater;
            request.updaterName = updaterName;

            var data = await _dataAccessService
                .OperateData(storeProcedure: "agdSp.uspTxnLogNoSaleUpdate", request);

			return ResponseHandler.ForBool(data, serviceName, method);
        }

        public async ValueTask<BasicResponse<bool>> DeleteTxnLogNoSale(int seqNo)
        {
			var method = _context?.HttpContext?.Request?.Method;
            
			var data = await _dataAccessService
                .OperateData(storeProcedure: "agdSp.uspTxnLogNoSaleDelete", new { seqNo = seqNo });

			return ResponseHandler.ForBool(data, serviceName, method);
        }

        public async ValueTask<BasicResponse<bool>> Exists(string? primaryRecordingID, int custKey, string customerID, string customerName, string flagType, string saleType, string? iDMark, string reviewStatus, string? reviewMemo, DateTime createDT, string creatorName, DateTime? reviewDT, string? reviewer, string? reviewerName)
        {
            var data = await _dataAccessService
                .LoadSingleData<int, object>(storeProcedure: "agdSp.uspTxnLogNoSaleExists", new
                {
					PrimaryRecordingID = primaryRecordingID,
					CustKey = custKey,
					CustomerID = customerID,
					CustomerName = customerName,
					FlagType = flagType,
					SaleType = saleType,
					IDMark = iDMark,
					ReviewStatus = reviewStatus,
					ReviewMemo = reviewMemo,
					CreateDT = createDT,
					CreatorName = creatorName,
					ReviewDT = reviewDT,
					Reviewer = reviewer,
					ReviewerName = reviewerName,               
                });

            if (data == 0)
            {
                return ResponseHandler.ForCustomBool(serviceName, false, "資料不存在");
            }
            else
            {
                return ResponseHandler.ForCustomBool(serviceName, true, "資料存在");
            }
        }
    }
}