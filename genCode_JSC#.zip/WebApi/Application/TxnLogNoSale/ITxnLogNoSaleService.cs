﻿using ESUN.AGD.WebApi.Application.TxnLogNoSale.Contract;

namespace ESUN.AGD.WebApi.Application.TxnLogNoSale
{
    public interface ITxnLogNoSaleService
    {
        /// <summary>
        /// 依序號取得交易紀錄-不行銷註記設定
        /// </summary>
        /// <param>
		/// seqNo            - int        - 流水號
        /// </param>
        /// <returns>
		/// seqNo            - int        - 流水號
		/// primaryRecordingID - string     - 主要錄音ID
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// flagType         - string     - 註記類別
		/// saleType         - string     - 註記結果
		/// iDMark           - string     - ID重號註記
		/// reviewStatus     - string     - 覆核狀態
		/// reviewMemo       - string     - 覆核備註
		/// createDT         - DateTime   - 建立時間
		/// creator          - string     - 建立者
		/// creatorName      - string     - 建立人員
		/// reviewDT         - DateTime   - 完成覆核時間
		/// reviewer         - string     - 覆核者
		/// reviewerName     - string     - 覆核人員
        /// </returns>
        ValueTask<BasicResponse<TxnLogNoSaleResponse>> GetTxnLogNoSale(int seqNo);

        /// <summary>
        /// 搜尋交易紀錄-不行銷註記設定 
        /// </summary>
        /// <param name="request">
		/// seqNo            - int        - 流水號
		/// primaryRecordingID - string     - 主要錄音ID
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// flagType         - string     - 註記類別
		/// saleType         - string     - 註記結果
		/// iDMark           - string     - ID重號註記
		/// reviewStatus     - string     - 覆核狀態
		/// reviewMemo       - string     - 覆核備註
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
		/// reviewDT         - DateTime   - 完成覆核時間
		/// reviewer         - string     - 覆核者
		/// reviewerName     - string     - 覆核人員
        /// page             - int        - 分頁
        /// rowsPerPage      - int        - 每頁筆數
        /// sortColumn       - string     - 排序欄位
        /// sortOrder        - string     - 排序順序
        /// </param>
        /// <returns>
		/// seqNo            - int        - 流水號
		/// primaryRecordingID - string     - 主要錄音ID
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// flagType         - string     - 註記類別
		/// saleType         - string     - 註記結果
		/// iDMark           - string     - ID重號註記
		/// reviewStatus     - string     - 覆核狀態
		/// reviewMemo       - string     - 覆核備註
		/// createDT         - DateTime   - 建立時間
		/// creator          - string     - 建立者
		/// creatorName      - string     - 建立人員
		/// reviewDT         - DateTime   - 完成覆核時間
		/// reviewer         - string     - 覆核者
		/// reviewerName     - string     - 覆核人員
        /// </returns> 
        ValueTask<BasicResponse<List<TxnLogNoSaleResponse>>> QueryTxnLogNoSale(TxnLogNoSaleQueryRequest request);

        /// <summary>
        /// 新增交易紀錄-不行銷註記設定 
        /// </summary>
        /// <param name="request">
		/// primaryRecordingID - string     - 主要錄音ID
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// flagType         - string     - 註記類別
		/// saleType         - string     - 註記結果
		/// iDMark           - string     - ID重號註記
		/// reviewStatus     - string     - 覆核狀態
		/// reviewMemo       - string     - 覆核備註
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
		/// reviewDT         - DateTime   - 完成覆核時間
		/// reviewer         - string     - 覆核者
		/// reviewerName     - string     - 覆核人員
        /// </param>
        /// <returns>
        /// </returns>
        ValueTask<BasicResponse<bool>> InsertTxnLogNoSale(TxnLogNoSaleInsertRequest request);

        /// <summary>
        /// 更新交易紀錄-不行銷註記設定
        /// </summary>
        /// <param name="request">
		/// primaryRecordingID - string     - 主要錄音ID
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// flagType         - string     - 註記類別
		/// saleType         - string     - 註記結果
		/// iDMark           - string     - ID重號註記
		/// reviewStatus     - string     - 覆核狀態
		/// reviewMemo       - string     - 覆核備註
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
		/// reviewDT         - DateTime   - 完成覆核時間
		/// reviewer         - string     - 覆核者
		/// reviewerName     - string     - 覆核人員
        /// </param>
        /// <returns>
        /// </returns>
        ValueTask<BasicResponse<bool>> UpdateTxnLogNoSale(TxnLogNoSaleUpdateRequest request);

        /// <summary>
        /// 刪除交易紀錄-不行銷註記設定
        /// </summary>
        /// <param>
		/// seqNo            - int        - 流水號
        /// </param>
        /// <returns>
        /// </returns>
        ValueTask<BasicResponse<bool>> DeleteTxnLogNoSale(int seqNo);

        /// <summary>
        /// 檢查交易紀錄-不行銷註記是否存在
        /// </summary>
        /// <param>
		/// primaryRecordingID - string     - 主要錄音ID
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// flagType         - string     - 註記類別
		/// saleType         - string     - 註記結果
		/// iDMark           - string     - ID重號註記
		/// reviewStatus     - string     - 覆核狀態
		/// reviewMemo       - string     - 覆核備註
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
		/// reviewDT         - DateTime   - 完成覆核時間
		/// reviewer         - string     - 覆核者
		/// reviewerName     - string     - 覆核人員
        /// </param>
        /// <returns>
        /// </returns>
        ValueTask<BasicResponse<bool>> Exists(string? primaryRecordingID, int custKey, string customerID, string customerName, string flagType, string saleType, string? iDMark, string reviewStatus, string? reviewMemo, DateTime createDT, string creatorName, DateTime? reviewDT, string? reviewer, string? reviewerName);

    }
}
