﻿using ESUN.AGD.WebApi.Application.LoginOutLog;
using ESUN.AGD.WebApi.Application.LoginOutLog.Contract;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ESUN.AGD.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginOutLogController : Controller
    {

        private readonly ILoginOutLogService _LoginOutLogService;

        public LoginOutLogController(ILoginOutLogService LoginOutLogService)
        {
            _LoginOutLogService = LoginOutLogService;
        }

        /// <summary>
        /// 依序號取得登出入紀錄設定
        /// </summary>
        /// <param>
		/// userID           - string     - 員工編號
		/// createDT         - DateTime   - 建立時間
        /// </param>
        /// <returns>
		/// seqNo            - int        - 流水號
		/// userID           - string     - 員工編號
		/// userName         - string     - 員工姓名
		/// loginIP          - string     - 登入IP
		/// loginSystemType  - string     - 登入系統類別
		/// loginDT          - DateTime   - 登入時間
		/// logoutDT         - DateTime   - 登出時間
		/// createDT         - DateTime   - 建立時間
		/// creator          - string     - 建立者
		/// creatorName      - string     - 建立人員
        /// </returns>
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("{userID,createDT}")]
        public async ValueTask<IActionResult> GetLoginOutLog(string userID,DateTime createDT)
        {
            return Ok(await _LoginOutLogService.GetLoginOutLog(userID,createDT));
        }

        /// <summary>
        /// 搜尋登出入紀錄設定 
        /// </summary>
        /// <param name="request">
		/// seqNo            - int        - 流水號
		/// userID           - string     - 員工編號
		/// userName         - string     - 員工姓名
		/// loginIP          - string     - 登入IP
		/// loginSystemType  - string     - 登入系統類別
		/// loginDT          - DateTime   - 登入時間
		/// logoutDT         - DateTime   - 登出時間
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
        /// page             - int        - 分頁
        /// rowsPerPage      - int        - 每頁筆數
        /// sortColumn       - string     - 排序欄位
        /// sortOrder        - bool       - 排序順序
        /// </param>
        /// <returns>
		/// seqNo            - int        - 流水號
		/// userID           - string     - 員工編號
		/// userName         - string     - 員工姓名
		/// loginIP          - string     - 登入IP
		/// loginSystemType  - string     - 登入系統類別
		/// loginDT          - DateTime   - 登入時間
		/// logoutDT         - DateTime   - 登出時間
		/// createDT         - DateTime   - 建立時間
		/// creator          - string     - 建立者
		/// creatorName      - string     - 建立人員
        /// </returns>
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]       
        [HttpGet("Query")]
        public async ValueTask<IActionResult> QueryLoginOutLog([FromQuery] LoginOutLogQueryRequest request)
        {
            return Ok(await _LoginOutLogService.QueryLoginOutLog(request));
        }

        /// <summary>
        /// 新增登出入紀錄設定 
        /// </summary>
        /// <param name="request">
		/// userID           - string     - 員工編號
		/// userName         - string     - 員工姓名
		/// loginIP          - string     - 登入IP
		/// loginSystemType  - string     - 登入系統類別
		/// loginDT          - DateTime   - 登入時間
		/// logoutDT         - DateTime   - 登出時間
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
        /// </param>
        /// <returns>
        /// </returns>
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]        
        [HttpPost]
        public async ValueTask<IActionResult> InsertLoginOutLog(LoginOutLogInsertRequest request)
        {
            return Ok(await _LoginOutLogService.InsertLoginOutLog(request));
        }

        /// <summary>
        /// 更新登出入紀錄設定
        /// </summary>
        /// <param name="request">
		/// userID           - string     - 員工編號
		/// userName         - string     - 員工姓名
		/// loginIP          - string     - 登入IP
		/// loginSystemType  - string     - 登入系統類別
		/// loginDT          - DateTime   - 登入時間
		/// logoutDT         - DateTime   - 登出時間
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
        /// </param>
        /// <returns>
        /// </returns>
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPut]
        public async ValueTask<IActionResult> UpdateLoginOutLog(LoginOutLogUpdateRequest request)
        {
            return Ok(await _LoginOutLogService.UpdateLoginOutLog(request));
        }

        /// <summary>
        /// 刪除登出入紀錄設定
        /// </summary>
        /// <param>
		/// userID           - string     - 員工編號
		/// createDT         - DateTime   - 建立時間
        /// </param>
        /// <returns></returns>
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpDelete]
        public async ValueTask<IActionResult> DeteleLoginOutLog(string userID,DateTime createDT)
        {
            return Ok(await _LoginOutLogService.DeleteLoginOutLog(userID,createDT));
        }

    }
}
