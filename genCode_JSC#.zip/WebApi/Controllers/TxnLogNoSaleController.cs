﻿using ESUN.AGD.WebApi.Application.TxnLogNoSale;
using ESUN.AGD.WebApi.Application.TxnLogNoSale.Contract;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ESUN.AGD.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TxnLogNoSaleController : Controller
    {

        private readonly ITxnLogNoSaleService _TxnLogNoSaleService;

        public TxnLogNoSaleController(ITxnLogNoSaleService TxnLogNoSaleService)
        {
            _TxnLogNoSaleService = TxnLogNoSaleService;
        }

        /// <summary>
        /// 依序號取得交易紀錄-不行銷註記設定
        /// </summary>
        /// <param>
		/// seqNo            - int        - 流水號
        /// </param>
        /// <returns>
		/// seqNo            - int        - 流水號
		/// primaryRecordingID - string     - 主要錄音ID
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// flagType         - string     - 註記類別
		/// saleType         - string     - 註記結果
		/// iDMark           - string     - ID重號註記
		/// reviewStatus     - string     - 覆核狀態
		/// reviewMemo       - string     - 覆核備註
		/// createDT         - DateTime   - 建立時間
		/// creator          - string     - 建立者
		/// creatorName      - string     - 建立人員
		/// reviewDT         - DateTime   - 完成覆核時間
		/// reviewer         - string     - 覆核者
		/// reviewerName     - string     - 覆核人員
        /// </returns>
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("{seqNo}")]
        public async ValueTask<IActionResult> GetTxnLogNoSale(int seqNo)
        {
            return Ok(await _TxnLogNoSaleService.GetTxnLogNoSale(seqNo));
        }

        /// <summary>
        /// 搜尋交易紀錄-不行銷註記設定 
        /// </summary>
        /// <param name="request">
		/// seqNo            - int        - 流水號
		/// primaryRecordingID - string     - 主要錄音ID
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// flagType         - string     - 註記類別
		/// saleType         - string     - 註記結果
		/// iDMark           - string     - ID重號註記
		/// reviewStatus     - string     - 覆核狀態
		/// reviewMemo       - string     - 覆核備註
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
		/// reviewDT         - DateTime   - 完成覆核時間
		/// reviewer         - string     - 覆核者
		/// reviewerName     - string     - 覆核人員
        /// page             - int        - 分頁
        /// rowsPerPage      - int        - 每頁筆數
        /// sortColumn       - string     - 排序欄位
        /// sortOrder        - bool       - 排序順序
        /// </param>
        /// <returns>
		/// seqNo            - int        - 流水號
		/// primaryRecordingID - string     - 主要錄音ID
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// flagType         - string     - 註記類別
		/// saleType         - string     - 註記結果
		/// iDMark           - string     - ID重號註記
		/// reviewStatus     - string     - 覆核狀態
		/// reviewMemo       - string     - 覆核備註
		/// createDT         - DateTime   - 建立時間
		/// creator          - string     - 建立者
		/// creatorName      - string     - 建立人員
		/// reviewDT         - DateTime   - 完成覆核時間
		/// reviewer         - string     - 覆核者
		/// reviewerName     - string     - 覆核人員
        /// </returns>
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]       
        [HttpGet("Query")]
        public async ValueTask<IActionResult> QueryTxnLogNoSale([FromQuery] TxnLogNoSaleQueryRequest request)
        {
            return Ok(await _TxnLogNoSaleService.QueryTxnLogNoSale(request));
        }

        /// <summary>
        /// 新增交易紀錄-不行銷註記設定 
        /// </summary>
        /// <param name="request">
		/// primaryRecordingID - string     - 主要錄音ID
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// flagType         - string     - 註記類別
		/// saleType         - string     - 註記結果
		/// iDMark           - string     - ID重號註記
		/// reviewStatus     - string     - 覆核狀態
		/// reviewMemo       - string     - 覆核備註
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
		/// reviewDT         - DateTime   - 完成覆核時間
		/// reviewer         - string     - 覆核者
		/// reviewerName     - string     - 覆核人員
        /// </param>
        /// <returns>
        /// </returns>
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]        
        [HttpPost]
        public async ValueTask<IActionResult> InsertTxnLogNoSale(TxnLogNoSaleInsertRequest request)
        {
            return Ok(await _TxnLogNoSaleService.InsertTxnLogNoSale(request));
        }

        /// <summary>
        /// 更新交易紀錄-不行銷註記設定
        /// </summary>
        /// <param name="request">
		/// primaryRecordingID - string     - 主要錄音ID
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// flagType         - string     - 註記類別
		/// saleType         - string     - 註記結果
		/// iDMark           - string     - ID重號註記
		/// reviewStatus     - string     - 覆核狀態
		/// reviewMemo       - string     - 覆核備註
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
		/// reviewDT         - DateTime   - 完成覆核時間
		/// reviewer         - string     - 覆核者
		/// reviewerName     - string     - 覆核人員
        /// </param>
        /// <returns>
        /// </returns>
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPut]
        public async ValueTask<IActionResult> UpdateTxnLogNoSale(TxnLogNoSaleUpdateRequest request)
        {
            return Ok(await _TxnLogNoSaleService.UpdateTxnLogNoSale(request));
        }

        /// <summary>
        /// 刪除交易紀錄-不行銷註記設定
        /// </summary>
        /// <param>
		/// seqNo            - int        - 流水號
        /// </param>
        /// <returns></returns>
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpDelete]
        public async ValueTask<IActionResult> DeteleTxnLogNoSale(int seqNo)
        {
            return Ok(await _TxnLogNoSaleService.DeleteTxnLogNoSale(seqNo));
        }

    }
}
