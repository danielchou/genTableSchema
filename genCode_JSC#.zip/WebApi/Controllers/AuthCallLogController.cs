﻿using ESUN.AGD.WebApi.Application.AuthCallLog;
using ESUN.AGD.WebApi.Application.AuthCallLog.Contract;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ESUN.AGD.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthCallLogController : Controller
    {

        private readonly IAuthCallLogService _AuthCallLogService;

        public AuthCallLogController(IAuthCallLogService AuthCallLogService)
        {
            _AuthCallLogService = AuthCallLogService;
        }

        /// <summary>
        /// 依序號取得國際電話申請紀錄設定
        /// </summary>
        /// <param>
		/// seqNo            - int        - 流水號
        /// </param>
        /// <returns>
		/// seqNo            - int        - 流水號
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// phoneNumber      - string     - 電話號碼
		/// authCallReason   - string     - 國際電話撥號原因
		/// approver         - string     - 審核人
		/// approverName     - string     - 審核人員
		/// approveDT        - DateTime   - 審核日期
		/// approveStatus    - string     - 審核狀態
		/// createDT         - DateTime   - 建立時間
		/// creator          - string     - 建立者
		/// creatorName      - string     - 建立人員
        /// </returns>
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("{seqNo}")]
        public async ValueTask<IActionResult> GetAuthCallLog(int seqNo)
        {
            return Ok(await _AuthCallLogService.GetAuthCallLog(seqNo));
        }

        /// <summary>
        /// 搜尋國際電話申請紀錄設定 
        /// </summary>
        /// <param name="request">
		/// seqNo            - int        - 流水號
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// phoneNumber      - string     - 電話號碼
		/// authCallReason   - string     - 國際電話撥號原因
		/// approver         - string     - 審核人
		/// approverName     - string     - 審核人員
		/// approveDT        - DateTime   - 審核日期
		/// approveStatus    - string     - 審核狀態
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
        /// page             - int        - 分頁
        /// rowsPerPage      - int        - 每頁筆數
        /// sortColumn       - string     - 排序欄位
        /// sortOrder        - bool       - 排序順序
        /// </param>
        /// <returns>
		/// seqNo            - int        - 流水號
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// phoneNumber      - string     - 電話號碼
		/// authCallReason   - string     - 國際電話撥號原因
		/// approver         - string     - 審核人
		/// approverName     - string     - 審核人員
		/// approveDT        - DateTime   - 審核日期
		/// approveStatus    - string     - 審核狀態
		/// createDT         - DateTime   - 建立時間
		/// creator          - string     - 建立者
		/// creatorName      - string     - 建立人員
        /// </returns>
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]       
        [HttpGet("Query")]
        public async ValueTask<IActionResult> QueryAuthCallLog([FromQuery] AuthCallLogQueryRequest request)
        {
            return Ok(await _AuthCallLogService.QueryAuthCallLog(request));
        }

        /// <summary>
        /// 新增國際電話申請紀錄設定 
        /// </summary>
        /// <param name="request">
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// phoneNumber      - string     - 電話號碼
		/// authCallReason   - string     - 國際電話撥號原因
		/// approver         - string     - 審核人
		/// approverName     - string     - 審核人員
		/// approveDT        - DateTime   - 審核日期
		/// approveStatus    - string     - 審核狀態
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
        /// </param>
        /// <returns>
        /// </returns>
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]        
        [HttpPost]
        public async ValueTask<IActionResult> InsertAuthCallLog(AuthCallLogInsertRequest request)
        {
            return Ok(await _AuthCallLogService.InsertAuthCallLog(request));
        }

        /// <summary>
        /// 更新國際電話申請紀錄設定
        /// </summary>
        /// <param name="request">
		/// custKey          - int        - 顧客識別流水號
		/// customerID       - string     - 顧客ID
		/// customerName     - string     - 顧客姓名
		/// phoneNumber      - string     - 電話號碼
		/// authCallReason   - string     - 國際電話撥號原因
		/// approver         - string     - 審核人
		/// approverName     - string     - 審核人員
		/// approveDT        - DateTime   - 審核日期
		/// approveStatus    - string     - 審核狀態
		/// createDT         - DateTime   - 建立時間
		/// creatorName      - string     - 建立人員
        /// </param>
        /// <returns>
        /// </returns>
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPut]
        public async ValueTask<IActionResult> UpdateAuthCallLog(AuthCallLogUpdateRequest request)
        {
            return Ok(await _AuthCallLogService.UpdateAuthCallLog(request));
        }

        /// <summary>
        /// 刪除國際電話申請紀錄設定
        /// </summary>
        /// <param>
		/// seqNo            - int        - 流水號
        /// </param>
        /// <returns></returns>
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpDelete]
        public async ValueTask<IActionResult> DeteleAuthCallLog(int seqNo)
        {
            return Ok(await _AuthCallLogService.DeleteAuthCallLog(seqNo));
        }

    }
}
