/****************************************************************
** Name: [agdSp].[uspFuncDelete]
** Desc: 功能刪除
**
** Return values: 0 成功
** Return Recordset: 
**	NA
**
** Called by: 
**	AGD WebApi
**
** Parameters:
**	Input
** -----------
	@FuncID          VARCHAR(20)  - 功能代碼
**
**   Output
** -----------
	@ErrorMsg NVARCHAR(100) - 錯誤回傳訊息
** 
** Example:
** -----------
	DECLARE @return_value INT
		,@FuncID VARCHAR(20)
		,@ErrorMsg NVARCHAR(100)

	SET @FuncID = ''

	EXEC @return_value = [agdSp].[uspFuncDelete] 
		@FuncID = @FuncID
		,@ErrorMsg = @ErrorMsg OUTPUT

	SELECT @return_value AS 'Return Value'
		,@ErrorMsg AS N'@ErrorMsg'
**
*****************************************************************
** Change History
*****************************************************************
** Date:		 	Author:				Description:
** ---------- ------- ------------------------------------
** 2022/04/10 20:12:03 	Jerry Yang			first release
*****************************************************************/
CREATE PROCEDURE [agdSp].[uspFuncDelete] (
	FuncID VARCHAR(20)
	,@ErrorMsg NVARCHAR(100) = NULL OUTPUT
	)
AS
SET NOCOUNT ON
SET @ErrorMsg = N''

BEGIN
	BEGIN TRY
		DELETE agdSet.tbFunc
		WHERE FuncID = @FuncID;
	END TRY

	BEGIN CATCH
		SELECT @ErrorMsg = LEFT(ERROR_MESSAGE(), 100)
	END CATCH
END

SET NOCOUNT OFF