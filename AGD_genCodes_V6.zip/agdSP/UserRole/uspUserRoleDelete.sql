/****************************************************************
** Name: [agdSp].[uspUserRoleDelete]
** Desc: 使用者角色配對刪除
**
** Return values: 0 成功
** Return Recordset: 
**	NA
**
** Called by: 
**	AGD WebApi
**
** Parameters:
**	Input
** -----------
	@UserID          VARCHAR(20)  - 使用者帳號
	@RoleID          VARCHAR(20)  - 角色代碼
**
**   Output
** -----------
	@ErrorMsg NVARCHAR(100) - 錯誤回傳訊息
** 
** Example:
** -----------
	DECLARE @return_value INT
		,@UserID VARCHAR(20)
		,@RoleID VARCHAR(20)
		,@ErrorMsg NVARCHAR(100)

	SET @UserID = ''
	SET @RoleID = ''

	EXEC @return_value = [agdSp].[uspUserRoleDelete] 
		@UserID = @UserID
		,@RoleID = @RoleID
		,@ErrorMsg = @ErrorMsg OUTPUT

	SELECT @return_value AS 'Return Value'
		,@ErrorMsg AS N'@ErrorMsg'
**
*****************************************************************
** Change History
*****************************************************************
** Date:		 	Author:				Description:
** ---------- ------- ------------------------------------
** 2022/04/10 20:12:03 	Jerry Yang			first release
*****************************************************************/
CREATE PROCEDURE [agdSp].[uspUserRoleDelete] (
	UserID VARCHAR(20)
,RoleID VARCHAR(20)
	,@ErrorMsg NVARCHAR(100) = NULL OUTPUT
	)
AS
SET NOCOUNT ON
SET @ErrorMsg = N''

BEGIN
	BEGIN TRY
		DELETE agdSet.tbUserRole
		WHERE UserID = @UserID AND RoleID = @RoleID;
	END TRY

	BEGIN CATCH
		SELECT @ErrorMsg = LEFT(ERROR_MESSAGE(), 100)
	END CATCH
END

SET NOCOUNT OFF