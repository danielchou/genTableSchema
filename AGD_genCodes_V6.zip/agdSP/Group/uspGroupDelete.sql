/****************************************************************
** Name: [agdSp].[uspGroupDelete]
** Desc: 群組刪除
**
** Return values: 0 成功
** Return Recordset: 
**	NA
**
** Called by: 
**	AGD WebApi
**
** Parameters:
**	Input
** -----------
	@GroupID         VARCHAR(20)  - 群組代碼
**
**   Output
** -----------
	@ErrorMsg NVARCHAR(100) - 錯誤回傳訊息
** 
** Example:
** -----------
	DECLARE @return_value INT
		,@GroupID VARCHAR(20)
		,@ErrorMsg NVARCHAR(100)

	SET @GroupID = ''

	EXEC @return_value = [agdSp].[uspGroupDelete] 
		@GroupID = @GroupID
		,@ErrorMsg = @ErrorMsg OUTPUT

	SELECT @return_value AS 'Return Value'
		,@ErrorMsg AS N'@ErrorMsg'
**
*****************************************************************
** Change History
*****************************************************************
** Date:		 	Author:				Description:
** ---------- ------- ------------------------------------
** 2022/04/10 20:12:03 	Jerry Yang			first release
*****************************************************************/
CREATE PROCEDURE [agdSp].[uspGroupDelete] (
	GroupID VARCHAR(20)
	,@ErrorMsg NVARCHAR(100) = NULL OUTPUT
	)
AS
SET NOCOUNT ON
SET @ErrorMsg = N''

BEGIN
	BEGIN TRY
		DELETE agdSet.tbGroup
		WHERE GroupID = @GroupID;
	END TRY

	BEGIN CATCH
		SELECT @ErrorMsg = LEFT(ERROR_MESSAGE(), 100)
	END CATCH
END

SET NOCOUNT OFF