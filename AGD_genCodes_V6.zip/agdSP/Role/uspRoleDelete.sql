/****************************************************************
** Name: [agdSp].[uspRoleDelete]
** Desc: 角色刪除
**
** Return values: 0 成功
** Return Recordset: 
**	NA
**
** Called by: 
**	AGD WebApi
**
** Parameters:
**	Input
** -----------
	@RoleID          VARCHAR(20)  - 角色代碼
**
**   Output
** -----------
	@ErrorMsg NVARCHAR(100) - 錯誤回傳訊息
** 
** Example:
** -----------
	DECLARE @return_value INT
		,@RoleID VARCHAR(20)
		,@ErrorMsg NVARCHAR(100)

	SET @RoleID = ''

	EXEC @return_value = [agdSp].[uspRoleDelete] 
		@RoleID = @RoleID
		,@ErrorMsg = @ErrorMsg OUTPUT

	SELECT @return_value AS 'Return Value'
		,@ErrorMsg AS N'@ErrorMsg'
**
*****************************************************************
** Change History
*****************************************************************
** Date:		 	Author:				Description:
** ---------- ------- ------------------------------------
** 2022/04/10 20:12:03 	Jerry Yang			first release
*****************************************************************/
CREATE PROCEDURE [agdSp].[uspRoleDelete] (
	RoleID VARCHAR(20)
	,@ErrorMsg NVARCHAR(100) = NULL OUTPUT
	)
AS
SET NOCOUNT ON
SET @ErrorMsg = N''

BEGIN
	BEGIN TRY
		DELETE agdSet.tbRole
		WHERE RoleID = @RoleID;
	END TRY

	BEGIN CATCH
		SELECT @ErrorMsg = LEFT(ERROR_MESSAGE(), 100)
	END CATCH
END

SET NOCOUNT OFF