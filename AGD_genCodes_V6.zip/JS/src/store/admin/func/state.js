export default () => ({
  items: [],
  item: {},
});
