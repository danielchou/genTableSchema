export const setItems = (state, value) => {
  state.items = value;
};

export const setItem = (state, value) => {
  state.item = value;
};
