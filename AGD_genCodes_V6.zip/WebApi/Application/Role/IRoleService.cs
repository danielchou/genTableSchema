﻿using ESUN.AGD.WebApi.Application.Role.Contract;

namespace ESUN.AGD.WebApi.Application.Role
{
    public interface IRoleService
    {
        /// <summary>
        /// 依序號取得角色設定
        /// </summary>
        /// <param>
        /// seqNo - 電腦電話序號
        /// </param>
        /// <returns>
		/// seqNo            - int        - 流水號
		/// roleID           - string     - 角色代碼
		/// roleName         - string     - 角色名稱
		/// createDT         - DateTime   - 建立時間
		/// creator          - string     - 建立者
		/// updateDT         - DateTime   - 更新時間
		/// updator          - string     - 更新者
        /// updatorName      - string     - 更新者名稱
        /// </returns>
        ValueTask<BasicResponse<RoleResponse>> GetRole(int seqNo);

        /// <summary>
        /// 搜尋角色設定 
        /// </summary>
        /// <param name="request">
		/// roleID           - string     - 角色代碼
		/// roleName         - string     - 角色名稱
        /// page             - int        - 分頁
        /// rowsPerPage      - int        - 每頁筆數
        /// sortColumn       - string     - 排序欄位
        /// sortOrder        - string     - 排序順序
        /// </param>
        /// <returns>
		/// seqNo            - int        - 流水號
		/// roleID           - string     - 角色代碼
		/// roleName         - string     - 角色名稱
		/// createDT         - DateTime   - 建立時間
		/// creator          - string     - 建立者
		/// updateDT         - DateTime   - 更新時間
		/// updator          - string     - 更新者
        /// updatorName      - string     - 更新者名稱
        /// </returns> 
        ValueTask<BasicResponse<List<RoleResponse>>> QueryRole(RoleQueryRequest request);

        /// <summary>
        /// 新增角色設定 
        /// </summary>
        /// <param name="request">
		/// roleID           - string     - 角色代碼
		/// roleName         - string     - 角色名稱
        /// </param>
        /// <returns>
        /// </returns>
        ValueTask<BasicResponse<bool>> InsertRole(RoleInsertRequest request);

        /// <summary>
        /// 更新角色設定
        /// </summary>
        /// <param name="request">
		/// seqNo            - int        - 流水號
		/// roleID           - string     - 角色代碼
		/// roleName         - string     - 角色名稱
        /// </param>
        /// <returns>
        /// </returns>
        ValueTask<BasicResponse<bool>> UpdateRole(RoleUpdateRequest request);

        /// <summary>
        /// 刪除角色設定
        /// </summary>
        /// <param>
		/// roleID           - string     - 角色代碼
        /// </param>
        /// <returns>
        /// </returns>
        ValueTask<BasicResponse<bool>> DeleteRole(string roleID);

        /// <summary>
        /// 檢查角色是否存在
        /// </summary>
        /// <param>
		/// roleID           - string     - 角色代碼
		/// roleName         - string     - 角色名稱
        /// </param>
        /// <returns>
        /// </returns>
        ValueTask<BasicResponse<bool>> Exists(string roleID,string roleName);

    }
}
